package com.sudonano.simplemanhunt.client.screens;

import org.checkerframework.checker.units.qual.h;

import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.client.Minecraft;

import com.sudonano.simplemanhunt.procedures.TimeDisplayOverlayIngameProcedure;
import com.sudonano.simplemanhunt.procedures.GetTimerTimeProcedure;

@EventBusSubscriber({Dist.CLIENT})
public class TimeOverlay {
	@SubscribeEvent(priority = EventPriority.HIGHEST)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getGuiGraphics().guiWidth();
		int h = event.getGuiGraphics().guiHeight();
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level();
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		if (TimeDisplayOverlayIngameProcedure.execute(world)) {
			event.getGuiGraphics().drawString(Minecraft.getInstance().font,

					GetTimerTimeProcedure.execute(world), w / 2 + 181, 9, -1, false);
		}
	}
}