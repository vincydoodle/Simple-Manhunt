package com.sudonano.simplemanhunt.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import com.sudonano.simplemanhunt.network.SimpleManhuntModVariables;

public class StartManhuntProcedure {
	public static void execute(LevelAccessor world, Entity entity, Entity hunted, Entity hunters) {
		if (entity == null || hunted == null || hunters == null)
			return;
		if (!SimpleManhuntModVariables.MapVariables.get(world).Hunting) {
			if (hunted != null) {
				if (hunters != null) {
					{
						SimpleManhuntModVariables.PlayerVariables _vars = hunted.getData(SimpleManhuntModVariables.PLAYER_VARIABLES);
						_vars.Hunted = true;
						_vars.syncPlayerVariables(hunted);
					}
					if (hunted instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal("You are being hunted..."), true);
					if (hunters instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal("The hunting begins..."), true);
					if (world instanceof ServerLevel _level) {
						LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
						entityToSpawn.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(hunted.getX(), hunted.getY(), hunted.getZ())));
						entityToSpawn.setVisualOnly(true);
						_level.addFreshEntity(entityToSpawn);
					}
					if (hunters instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 255, false, false));
					if (hunters instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 255, false, false));
					SimpleManhuntModVariables.MapVariables.get(world).Hunting = true;
					SimpleManhuntModVariables.MapVariables.get(world).syncData(world);
				}
			}
		} else {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Stop the current manhunt first! (/manhunt stop)"), false);
		}
	}
}