package com.sudonano.simplemanhunt.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;

import com.sudonano.simplemanhunt.network.SimpleManhuntModVariables;

public class StopManhuntProcedure {
	public static void execute(LevelAccessor world) {
		for (Entity entityiterator : new ArrayList<>(world.players())) {
			{
				SimpleManhuntModVariables.PlayerVariables _vars = entityiterator.getData(SimpleManhuntModVariables.PLAYER_VARIABLES);
				_vars.Hunted = false;
				_vars.syncPlayerVariables(entityiterator);
			}
		}
		SimpleManhuntModVariables.MapVariables.get(world).Hunting = false;
		SimpleManhuntModVariables.MapVariables.get(world).syncData(world);
		SimpleManhuntModVariables.MapVariables.get(world).where_cooldown = false;
		SimpleManhuntModVariables.MapVariables.get(world).syncData(world);
		SimpleManhuntModVariables.MapVariables.get(world).ticks = 0;
		SimpleManhuntModVariables.MapVariables.get(world).syncData(world);
		SimpleManhuntModVariables.MapVariables.get(world).where_ticks = 0;
		SimpleManhuntModVariables.MapVariables.get(world).syncData(world);
	}
}