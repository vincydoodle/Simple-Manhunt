package com.sudonano.simplemanhunt.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;

import com.sudonano.simplemanhunt.network.SimpleManhuntModVariables;
import com.sudonano.simplemanhunt.SimpleManhuntMod;

public class WherePorcendureProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		boolean has_coords = false;
		double x = 0;
		double z = 0;
		SimpleManhuntMod.LOGGER.info("Mcreator keeps crashing so I rage typed the name.");
		if (!SimpleManhuntModVariables.MapVariables.get(world).where_cooldown) {
			has_coords = false;
			for (Entity entityiterator : new ArrayList<>(world.players())) {
				if (entityiterator.getData(SimpleManhuntModVariables.PLAYER_VARIABLES).Hunted) {
					x = entityiterator.getX();
					z = entityiterator.getZ();
					has_coords = true;
				}
			}
			for (Entity entityiterator : new ArrayList<>(world.players())) {
				if (!entityiterator.getData(SimpleManhuntModVariables.PLAYER_VARIABLES).Hunted && has_coords) {
					if (entityiterator instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal(("Runner is at: " + x + " Y " + z + ".")), false);
				}
			}
			if (!has_coords) {
				if (!world.isClientSide() && world.getServer() != null)
					world.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Start a manhunt before getting runner position!"), false);
			} else {
				SimpleManhuntModVariables.MapVariables.get(world).where_cooldown = true;
				SimpleManhuntModVariables.MapVariables.get(world).syncData(world);
			}
		} else {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Wait for the cooldown!"), false);
		}
	}
}