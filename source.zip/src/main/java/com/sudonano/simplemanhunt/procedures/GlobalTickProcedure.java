package com.sudonano.simplemanhunt.procedures;

import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;

import javax.annotation.Nullable;

import com.sudonano.simplemanhunt.network.SimpleManhuntModVariables;

@EventBusSubscriber
public class GlobalTickProcedure {
	@SubscribeEvent
	public static void onWorldTick(LevelTickEvent.Post event) {
		execute(event, event.getLevel());
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		if (SimpleManhuntModVariables.MapVariables.get(world).Hunting) {
			SimpleManhuntModVariables.MapVariables.get(world).ticks = SimpleManhuntModVariables.MapVariables.get(world).ticks + 0.5;
			SimpleManhuntModVariables.MapVariables.get(world).syncData(world);
		}
		if (SimpleManhuntModVariables.MapVariables.get(world).where_ticks >= 3600) {
			SimpleManhuntModVariables.MapVariables.get(world).where_cooldown = false;
			SimpleManhuntModVariables.MapVariables.get(world).syncData(world);
		} else if (SimpleManhuntModVariables.MapVariables.get(world).where_cooldown) {
			SimpleManhuntModVariables.MapVariables.get(world).where_ticks = SimpleManhuntModVariables.MapVariables.get(world).where_ticks + 1;
			SimpleManhuntModVariables.MapVariables.get(world).syncData(world);
		}
	}
}