package com.sudonano.simplemanhunt.procedures;

import net.minecraft.world.level.LevelAccessor;

import com.sudonano.simplemanhunt.network.SimpleManhuntModVariables;

public class GetTimerTimeProcedure {
	public static String execute(LevelAccessor world) {
		if (SimpleManhuntModVariables.MapVariables.get(world).Hunting) {
			return ((Math.floor(SimpleManhuntModVariables.MapVariables.get(world).ticks / 144000) < 10
					? "0" + Math.floor(SimpleManhuntModVariables.MapVariables.get(world).ticks / 144000)
					: "" + Math.floor(SimpleManhuntModVariables.MapVariables.get(world).ticks / 144000))
					+ ":"
					+ (Math.floor(SimpleManhuntModVariables.MapVariables.get(world).ticks / 2400) % 60 < 10
							? "0" + Math.floor(SimpleManhuntModVariables.MapVariables.get(world).ticks / 2400) % 60
							: "" + Math.floor(SimpleManhuntModVariables.MapVariables.get(world).ticks / 2400) % 60)
					+ ":"
					+ (Math.floor(SimpleManhuntModVariables.MapVariables.get(world).ticks / 40) % 60 < 10
							? "0" + Math.floor(SimpleManhuntModVariables.MapVariables.get(world).ticks / 40) % 60
							: "" + Math.floor(SimpleManhuntModVariables.MapVariables.get(world).ticks / 40) % 60))
					.replace(".0", "");
		}
		return "00:00:00";
	}
}