package com.sudonano.simplemanhunt.procedures;

import net.minecraft.world.level.LevelAccessor;

import com.sudonano.simplemanhunt.network.SimpleManhuntModVariables;

public class TimeDisplayOverlayIngameProcedure {
	public static boolean execute(LevelAccessor world) {
		if (SimpleManhuntModVariables.MapVariables.get(world).Hunting) {
			return true;
		}
		return false;
	}
}