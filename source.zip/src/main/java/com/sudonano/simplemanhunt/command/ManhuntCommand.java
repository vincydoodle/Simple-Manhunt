package com.sudonano.simplemanhunt.command;

import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.Commands;
import net.minecraft.commands.CommandSourceStack;

import java.util.Collection;

import com.sudonano.simplemanhunt.procedures.StopManhuntProcedure;

import com.sudonano.simplemanhunt.procedures.StartManhuntProcedure;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.context.CommandContext;

@EventBusSubscriber
public class ManhuntCommand {
	@SubscribeEvent
	public static void registerCommand(RegisterCommandsEvent event) {
		event.getDispatcher()
				.register(Commands.literal("manhunt").then(Commands.literal("start").then(Commands.argument("hunters", EntityArgument.players()).then(Commands.argument("hunted", EntityArgument.player()).executes(context -> startManhunt(context)))))
						.then(Commands.literal("stop").executes(context -> stopManhunt(context))));
	}

	private static int startManhunt(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {

		Collection<ServerPlayer> hunters = EntityArgument.getPlayers(context, "hunters");
		ServerPlayer hunted = EntityArgument.getPlayer(context, "hunted");

		ServerLevel world = context.getSource().getLevel();
		ServerPlayer runner = context.getSource().getPlayer(); // person running command

		for (ServerPlayer hunter : hunters) {
			StartManhuntProcedure.execute(world, hunter, runner, hunted);
		}

		return 1;
	}

	private static int stopManhunt(CommandContext<CommandSourceStack> context) {
		ServerLevel world = context.getSource().getLevel();
		StopManhuntProcedure.execute(world);
		return 1;
	}
}